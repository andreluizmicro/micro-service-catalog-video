<?php declare(strict_types=1);

/**
 * @license Apache 2.0
 */

namespace OpenApi\Tests\Fixtures\PHP\Inheritance;

class ExtendsClass extends BaseClass
{
    public $extendsClassProp;

    public function extendsClassFunc()
    {
    }
}
