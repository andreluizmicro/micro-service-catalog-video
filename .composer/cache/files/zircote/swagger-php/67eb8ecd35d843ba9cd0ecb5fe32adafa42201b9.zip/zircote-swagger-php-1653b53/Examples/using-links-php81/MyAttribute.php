<?php declare(strict_types=1);

namespace OpenApi\Examples\UsingLinksPhp81;

#[\Attribute]
class MyAttribute
{
}
