<?php

namespace OpenApi\Examples\UsingTraits\Decoration;

trait UndocumentedBell
{
    public $undocumentedBell;
}
